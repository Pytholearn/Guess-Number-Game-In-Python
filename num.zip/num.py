import random

number = random.randint(0,9)

guss_number = int(input("Enter an integer from 0 to 9:"))

while(guss_number != number):

    if(guss_number > number):
        print("guess number is high!!")
        guss_number = int(input("Enter an integer from 0 to 9:"))
    elif(guss_number < number):
        print("guess number is low !!")
        guss_number = int(input("Enter an integer from 0 to 9:"))


    if(guss_number == number):
        print("you guessed it !"+ str(guss_number))
        
